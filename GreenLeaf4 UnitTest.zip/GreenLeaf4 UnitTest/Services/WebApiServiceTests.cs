using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace GreenLeaf4_UnitTest.Services
{
    [TestClass]
    public class WebApiServiceTests
    {
        private MockRepository mockRepository;



        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange


            // Act
            WebApiServiceTests service = this.CreateService();


            // Assert

        }

        private WebApiServiceTests CreateService()
        {
            return new WebApiServiceTests();
        }
    }
}
