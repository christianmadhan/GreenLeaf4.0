using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace GreenLeaf4_UnitTest.Global
{
    [TestClass]
    public class SingletonStationTests
    {
        private MockRepository mockRepository;



        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange


            // Act
            SingletonStationTests singletonStation = this.CreateSingletonStation();


            // Assert

        }

        private SingletonStationTests CreateSingletonStation()
        {
            return new SingletonStationTests();
        }
    }
}
