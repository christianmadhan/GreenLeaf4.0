﻿
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreenLeaf4_UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
