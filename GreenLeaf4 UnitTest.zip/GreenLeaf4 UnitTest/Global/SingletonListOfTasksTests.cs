using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace GreenLeaf4_UnitTest.Global
{
    [TestClass]
    public class SingletonListOfTasksTests
    {
        private MockRepository mockRepository;



        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange


            // Act
            SingletonListOfTasksTests singletonListOfTasks = this.CreateSingletonListOfTasks();


            // Assert

        }

        private SingletonListOfTasksTests CreateSingletonListOfTasks()
        {
            return new SingletonListOfTasksTests();
        }
    }
}
